/* Test comment */
define(function (require, exports, module) {
    CHANGED CHANGED = require("modules/CHANGED"),
        CHANGED = require("modules/CHANGED"),
        CHANGED = require("modules/CHANGED");
    
    function callFoo() {
        
        CHANGED();
        
    }

}
