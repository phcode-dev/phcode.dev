/*jslint vars: true, plusplus: true, devel: true, browser: true, nomen: true, indent: 4, maxerr: 50 */
/*global define, $ */
define(function (products) {
    'use strict';
	return {
		reserveProduct: function () {
			console.log("Function : reserveProduct");
			return true;
		}
    };
});
