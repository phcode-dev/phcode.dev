<!DOCTYPE html>
<html lang="en">
  <head>
    <style type="text/css">
{{0}}   body {
            background: url("<?php echo $img; ?>") no-repeat;
            background-size: 100% 100%;
            color: white;
        }
    </style>
  </head>

  <bo{{1}}dy onclick="goHome()"></body>
</html>