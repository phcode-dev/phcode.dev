// mispelled function keyword
funtion foo() {};